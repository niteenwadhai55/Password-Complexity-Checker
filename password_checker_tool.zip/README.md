
# Password Complexity Checker

This Python script evaluates the strength of a password based on specific criteria:

## Features
1. Checks password length (at least 8 characters).
2. Ensures the presence of uppercase and lowercase letters.
3. Validates the inclusion of at least one digit.
4. Checks for at least one special character.
5. Provides feedback to improve weak passwords.

## How to Use
1. Clone the repository:
    ```bash
    git clone <repository-link>
    cd <repository-folder>
    ```
2. Run the script:
    ```bash
    python password_checker.py
    ```
3. Follow the prompt to enter a password and get feedback.

## Example
### Input:
```
Enter your password: MySecurePass1!
```

### Output:
```
Password Strength: Strong password!
```

## Dependencies
- Python 3.x
- No external libraries required.

## License
This project is open-source and available under the [MIT License](LICENSE).
