
import re

def check_password_strength(password):
    # Initialize score
    score = 0
    feedback = []

    # Length check
    if len(password) >= 8:
        score += 1
    else:
        feedback.append("Password should be at least 8 characters long.")

    # Uppercase letter check
    if re.search(r"[A-Z]", password):
        score += 1
    else:
        feedback.append("Password should include at least one uppercase letter.")

    # Lowercase letter check
    if re.search(r"[a-z]", password):
        score += 1
    else:
        feedback.append("Password should include at least one lowercase letter.")

    # Digit check
    if re.search(r"\d", password):
        score += 1
    else:
        feedback.append("Password should include at least one number.")

    # Special character check
    if re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        score += 1
    else:
        feedback.append("Password should include at least one special character.")

    # Provide feedback based on score
    if score == 5:
        return "Strong password!", feedback
    elif score >= 3:
        return "Moderate password. Consider improving it.", feedback
    else:
        return "Weak password. Improve it.", feedback


if __name__ == "__main__":
    print("Password Complexity Checker")
    password = input("Enter your password: ")
    strength, tips = check_password_strength(password)
    print(f"Password Strength: {strength}")
    if tips:
        print("Suggestions:")
        for tip in tips:
            print(f"- {tip}")
